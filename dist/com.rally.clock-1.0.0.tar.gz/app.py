from PIL import Image, ImageDraw
from datetime import datetime

class App:
    def setup(self): pass
    def render(self):
        img = Image.new("RGB", (128, 32))
        d = ImageDraw.Draw(img)
        now = datetime.now()
        d.text((2, 6), now.strftime("%-I:%M %p"), fill=(255,255,255))
        d.text((2, 20), now.strftime("%a %b %-d"), fill=(180,180,180))
        return img
